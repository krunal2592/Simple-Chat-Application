package com.example.macstudent.simplechatapp;

import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

/**
 * Created by macstudent on 2018-04-17.
 */

public class List_Users extends AppCompatActivity {
    private ActionBar toolbar;
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private RecyclerViewAdapter adapter;
    private ArrayList<Person> mPersonList;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private DatabaseReference mUsersDBRef;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);

        mRecyclerView = (RecyclerView) findViewById(R.id.usersRecyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RecyclerViewAdapter(mPersonList,this.getApplicationContext());
        mRecyclerView.setAdapter(adapter);
        mAuth = FirebaseAuth.getInstance();

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        toolbar = getSupportActionBar();
        toolbar.setTitle("Users");


        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        mUsersDBRef = database.getReference("/Users");

        mUsersDBRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                mPersonList = new ArrayList<Person>();

                    int index = 0;
                    for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {

                            Person model = dataSnapshot1.getValue(Person.class);

                                if (!model.getUId().equals(mAuth.getCurrentUser().getUid())) {
                                    Person per = new Person();

                                    String name = model.getUName();
                                    // Toast.makeText(List_Users.this, name, Toast.LENGTH_LONG).show();
                                    String email = model.getUEmail();
                                    // Toast.makeText(List_Users.this, email, Toast.LENGTH_LONG).show();
                                    String img = model.getUImage();
                                    String ph = model.getUPhone();
                                    per.setUName(name);
                                    per.setUEmail(email);
                                    per.setUPhone(ph);

                                    per.setUImage(img);
                                    mPersonList.add(model);
                                    // String name1 =  mPersonList.get(index).getUName();
                                    //   index++;
                                    //  String name2 = mPersonList.get(0).getUName();
                                    //  Toast.makeText(List_Users.this,name2,Toast.LENGTH_LONG).show();
                                }

                    }

                RecyclerViewAdapter recyclerViewAdapter;
                recyclerViewAdapter = new RecyclerViewAdapter(mPersonList,List_Users.this);
                mRecyclerView.setAdapter(recyclerViewAdapter);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment fragment;
            switch (item.getItemId()) {
                case R.id.navigation_contact:
                    toolbar.setTitle("Contact");
                    return true;
                case R.id.navigation_settings:
                    toolbar.setTitle("Settings");
                    Intent intent = new Intent(List_Users.this,MainActivity.class);
                    startActivity(intent);
                    return true;
                case R.id.navigation_profile:
                    toolbar.setTitle("Profile");
                    Intent intent1 = new Intent(List_Users.this,User_Profile.class);
                    startActivity(intent1);
                    return true;
                case R.id.navigation_chat:
                    toolbar.setTitle("Chat");
                    return true;
            }
            return false;
        }
    };
}
