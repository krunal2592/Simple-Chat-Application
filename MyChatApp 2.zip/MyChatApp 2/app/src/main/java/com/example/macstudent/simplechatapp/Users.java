package com.example.macstudent.simplechatapp;



import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Users extends AppCompatActivity {
    private ActionBar toolbar;


    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private UserAdapter adapter;
    private ArrayList<Person> mUsersList = new ArrayList<Person>();
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private DatabaseReference mUsersDBRef;
    ProgressDialog pd;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);

        toolbar = getSupportActionBar();

        mAuth = FirebaseAuth.getInstance();
        mUsersDBRef = FirebaseDatabase.getInstance().getReference().child("Users");
        //initialize the recyclerview variables
        mRecyclerView = (RecyclerView) findViewById(R.id.usersRecyclerView);
        mRecyclerView.setHasFixedSize(true);
        // use a linear layout manager
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);


        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);


        toolbar.setTitle("Users");

        pd = new ProgressDialog(this);
        pd.setMessage("Loading...");
        pd.show();
        mAuth = FirebaseAuth.getInstance();
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user == null) {
                    pd.dismiss();
                    startActivity(new Intent(Users.this, LoginActivity.class));

                } else {

//                    UserDetails.userID = user.getUid();
//                    UserDetails.userEmail = user.getEmail();
                }
            }
        };


        mUsersDBRef = FirebaseDatabase.getInstance().getReference("/Users");
        // usersList = (ListView) findViewById(R.id.usersList);
        //noUsersText = (TextView) findViewById(R.id.noUsersText);


//        private void queryUserAndAddThem()
//        {
//            mUsersDBRef.addValueEventListener(new ValueEventListener() {
//                @Override
//                public void onDataChange(DataSnapshot dataSnapshot) {
//                    if(dataSnapshot.getChildrenCount() > 0){
//                        for(DataSnapshot snap: dataSnapshot.getChildren()){
//                            UserDetails user = snap.getValue(UserDetails.class);
//                            //if not current user, as we do not want to show ourselves then chat with ourselves lol
//                            try {
//                                if(!user.getUserId().equals(mAuth.getCurrentUser().getUid())){
//                                    mUsersList.add(user);
//                                }
//                            } catch (Exception e) {
//                                e.printStackTrace();
//                            }
//                        }
//                    }
//
//                    /**populate listview**/
//                    populaterecyclerView();
//
//                }
//
//                @Override
//                public void onCancelled(DatabaseError databaseError) {
//
//                }
//            });
//        }

        mUsersDBRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                //mUsersList = new ArrayList<UserDetails>();
                int index = 0;
                //if (dataSnapshot.getChildrenCount() > 0) {
//                    for (DataSnapshot snap : dataSnapshot.getChildren()) {
//                        UserDetails userDetails = snap.getValue(UserDetails.class);
//                        //if not current user, as we do not want to show ourselves then chat with ourselves lol
//
//                       // if (!userDetails.getUserId().equals(mAuth.getCurrentUser().getUid())) {
//                            UserDetails usr = new UserDetails();
//                            String name = userDetails.getUserName();
//                           // Toast.makeText(Users.this, name, Toast.LENGTH_LONG).show();
//                            String email = userDetails.getUserEmail();
//                            //Toast.makeText(Users.this, email, Toast.LENGTH_LONG).show();
//                            String img = userDetails.getUserImage();
//                            String ph = userDetails.getUserPhone();
//                            usr.setUserName(name);
//                            usr.setUserEmail(email);
//                            usr.setUserPhone(ph);
//
//                            usr.setUserImage(img);
//
//                             String name3  = usr.getUserName();
//                            mUsersList.add(userDetails);
//                            String name4  = mUsersList.get(index).getUserName();
//
//                            if(index == 1){
//                                String name5  = mUsersList.get(0).getUserName();
//                                Log.d("Username :- ", name5);
//                            }
//
//                            index = index + 1;
//                            // Toast.makeText(Users.this, (CharSequence) mUsersList,Toast.LENGTH_LONG).show();
//                            Log.d("Username :- ", userDetails.getUserName());
//                       // }
//
//                    }
//



                    for(int i = 0 ; i< 2 ;i++){
                        Person person = new Person();
                        person.setUName("safd"+i);
//                            usr.setUserEmail(email);
//                            usr.setUserPhone(ph);
//
//                            usr.setUserImage(img);
                        mUsersList.add(person);
                        String name1  = mUsersList.get(index).getUName();
                        index++;
                      // String name2  = mUsersList.get(1).getUName();

                    }

                    adapter = new UserAdapter(Users.this,mUsersList);
                    mRecyclerView.setAdapter(adapter);

               // }



                String name1  = mUsersList.get(0).getUName();
                String name2  = mUsersList.get(1).getUName();

                /**populate listview**/
               // populaterecyclerView();
                //mRecyclerView.setAdapter(adapter);

                pd.dismiss();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

//        mUsersList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                final String checkChild = al.get(position);
//                UserDetails.chatwithEmail = checkChild;
//                Utils.valueEventListener(mUsersDBRef, checkChild);
//                startActivity(new Intent(Users.this, Chat.class));
//            }
//        });


    private void populaterecyclerView(){





    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment fragment;
            switch (item.getItemId()) {
                case R.id.navigation_contact:
                    toolbar.setTitle("Contact");
                    return true;
                case R.id.navigation_settings:
                    toolbar.setTitle("Settings");
                    return true;
                case R.id.navigation_profile:
                    toolbar.setTitle("Profile");
                    Intent intent = new Intent(Users.this,UserInfo.class);
                    startActivity(intent);
                    return true;

            }
            return false;
        }
    };


    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);

    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }
}
