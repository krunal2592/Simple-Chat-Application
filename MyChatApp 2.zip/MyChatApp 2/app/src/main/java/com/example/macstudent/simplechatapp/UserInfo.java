package com.example.macstudent.simplechatapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created by macstudent on 2018-04-03.
 */

public class UserInfo extends AppCompatActivity {
    private byte[] byteArray = null;
    private ActionBar toolbar;

    EditText username, useremail, userphone;
    ImageView userimage;
    Button savebtn;
    private Uri file;
    private Bundle extras;


    static final int REQUEST_IMAGE_CAPTURE = 1;
    static final int REQUEST_IMAGE_PICK = 2;
    private DatabaseReference mUserDBRef;
    private StorageReference mStorageRef;

    private Bitmap bitmap;


   final DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("/Users");



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);



        Intent intent = getIntent();
        String email = intent.getStringExtra("Email");
        String phone = intent.getStringExtra("Phone");

        username = findViewById(R.id.userName);
        useremail = findViewById(R.id.emailId);


        userphone = findViewById(R.id.phoneNo);
        userimage = findViewById(R.id.userPhotoUpload);

        savebtn = findViewById(R.id.btn_submit_usrinfo);
        if(email.toString().equals(" ")) {

            useremail.setHint("Enter Email");
            userphone.setText(phone.toString());
        }else
        {
            useremail.setText(email.toString());
            userphone.setHint("Enter Phone Number");
        }
        toolbar = getSupportActionBar();
        toolbar.setTitle("User Profile");

        //init firebase
        mUserDBRef = FirebaseDatabase.getInstance().getReference().child("Users");
        mStorageRef = FirebaseStorage.getInstance().getReferenceFromUrl("gs://chatapplication-9a76e.appspot.com").child("images/");



        userimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(UserInfo.this);
                builder.setTitle("Upload Photo");
                builder.setMessage("Choose the method to upload the photo");
                builder.setPositiveButton("Gallery", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        pickPhotoFromGallery();
                    }
                });
                builder.setNegativeButton("Camera", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        pickPhotoFromCamera();
                    }
                });
                builder.create().show();
            }
        });






        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//
                mStorageRef = FirebaseStorage.getInstance().getReferenceFromUrl("gs://chatapplication-9a76e.appspot.com").child("Users_image/" + UUID.randomUUID().toString());
                UploadTask uploadTask = mStorageRef.putFile(file);
                uploadTask.addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                       // Toast.makeText(this, "Error : "+e.toString(),Toast.LENGTH_SHORT).show();
                    }
                }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        String currentUser = FirebaseAuth.getInstance().getUid();

                        String username1 = username.getText().toString();
                        String useremail1 = useremail.getText().toString();
                        String userphone1 = userphone.getText().toString();

                        Map<String, Object> userDetails = new HashMap<>();
                        userDetails.put("uID", currentUser);
                        userDetails.put("uName", username1);
                        userDetails.put("uEmail", useremail1);
                        userDetails.put("uPhone", userphone1);
                        userDetails.put("uImage", taskSnapshot.getDownloadUrl().toString());
                       mUserDBRef.child(currentUser).setValue(userDetails);
                        startActivity(new Intent(UserInfo.this, List_Users.class));
                        finish();
                    }
                });



            }
        });




    }



    private void pickPhotoFromGallery() {
        Intent photopickerIntent = new Intent(Intent.ACTION_PICK);
        photopickerIntent.setType("image/*");
        startActivityForResult(photopickerIntent, REQUEST_IMAGE_PICK);

    }

    private void pickPhotoFromCamera() {
        Intent takepicIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takepicIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takepicIntent, REQUEST_IMAGE_CAPTURE);

        }
    }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);

            if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK ) {
                file = Uri.parse(data.getExtras().get("data").toString());

                Bitmap imageBitmap = (Bitmap) data.getExtras().get("data");
                userimage.setImageBitmap(imageBitmap);
                /**convert bitmap to byte array to store in firebase storage**/
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                imageBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byteArray = stream.toByteArray();

            } else if (requestCode == REQUEST_IMAGE_PICK && resultCode == RESULT_OK && data != null && data.getData() != null)  {

                file = data.getData();
                try {

                    bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), file);
                    userimage.setImageBitmap(bitmap);

                } catch (IOException e) {
                    e.printStackTrace();
                }



            }






    }



}
