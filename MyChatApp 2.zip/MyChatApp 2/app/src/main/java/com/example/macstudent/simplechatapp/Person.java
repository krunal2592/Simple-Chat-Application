package com.example.macstudent.simplechatapp;



/**
 * Created by macstudent on 2018-04-16.
 */

public class Person {
    private String uID = "";
    private String uEmail = "";

    private String uName = "";
    private String uPhone = "";
    private String uImage = "";



    public String getUName() {
        return uName;
    }


    public String getUId() {
        return uID;
    }
    public void setUId(String uID) {

        this.uID = uID;
    }
    public String getUEmail() {
        return uEmail;
    }

    public String getUImage() {
        return uImage;
    }
    public String getUPhone() {
        return uPhone;
    }

    public void setUImage(String uImage) {
        this.uImage = uImage;
    }
    public void setUName(String uName) {
        this.uName = uName;
    }
    public void setUEmail(String uEmail) {
        this.uEmail = uEmail;
    }
    public void setUPhone(String uPhone) {
        this.uPhone = uPhone;
    }



    public Person(){}
}

