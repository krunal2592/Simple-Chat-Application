package com.example.macstudent.simplechatapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by macstudent on 2018-04-17.
 */

class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>  {
    private List<Person> mDataset;
    Context context;

    RecyclerViewAdapter(List<Person> dataset, Context context)
    {
        mDataset = dataset;
        this.context = context;
    }

    @Override
    public RecyclerViewAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_list,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(RecyclerViewAdapter.ViewHolder holder, int position) {
        final Person mperson = mDataset.get(position);
        holder.userTextName.setText(mperson.getUName());
        Picasso.get().load(mperson.getUImage()).placeholder(R.drawable.user_profile)
                .into(holder.person_userImage);

        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //send this user id to chat messages activity
                goToChat(mperson.getUId().toString());
            }
        });

    }

    private void goToChat(String personId) {
        Intent goToUpdate = new Intent(context, ChatMessagesActivity.class);
        goToUpdate.putExtra("USER_ID", personId);
        context.startActivity(goToUpdate);
    }

    @Override
    public int getItemCount() {
        int arr = 0;

        try{
            if(mDataset.size()==0){

                arr = 0;

            }
            else{

                arr=mDataset.size();
            }



        }catch (Exception e){



        }

        return arr;
    }

    class ViewHolder extends RecyclerView.ViewHolder
    {
        public TextView userTextName;
        public ImageView person_userImage;
        public View layout;

        public ViewHolder(View itemView) {
            super(itemView);
            layout = itemView;
            userTextName = (TextView) itemView.findViewById(R.id.userName);
            person_userImage = (ImageView) itemView.findViewById(R.id.userImage);
        }
    }
}
