package com.example.macstudent.simplechatapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import static android.widget.Toast.LENGTH_LONG;

/**
 * Created by macstudent on 2018-04-04.
 */

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {

    private List<Person> userlist;
    private Context context;



//    public void add(int position, UserDetails person) {
//        userlist.add(position, person);
//        notifyItemInserted(position);
//    }
//
//    public void remove(int position) {
//        userlist.remove(position);
//        notifyItemRemoved(position);
//    }


    // Provide a suitable constructor (depends on the kind of dataset)
    public UserAdapter(Context context,List<Person> myDataset) {


        userlist = myDataset;
        this.context = context;

    }

    // Create new views (invoked by the layout manager)
    @Override
    public UserAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                     int viewType) {
        // create a new view
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v = inflater.inflate(R.layout.custom_list, parent, false);
        // set the view's size, margins, paddings and layout parameters
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(ViewHolder holder,  int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element

        final Person person = userlist.get(position);


        holder.userTextName.setText(person.getUName());

        try {
//            Glide.with(context)
//                    .load(userDetails.getUserImage())
//                    .into(holder.userImage);
           Picasso.get().load(person.getUImage()).placeholder(R.drawable.user_profile)
                   .into(holder.person_userImage);
        } catch (Exception e) {

            e.printStackTrace();
        }

        //listen to single view layout click
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //send this user id to chat messages activity
                String id = person.getUId();
                goToUpdateActivity(person.getUId());

            }
        });


    }

    private void goToUpdateActivity(String personId) {
        Intent goToUpdate = new Intent(context, ChatMessagesActivity.class);
        goToUpdate.putExtra("USER_ID", personId);
        context.startActivity(goToUpdate);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView userTextName;
        public ImageView person_userImage;

        public View layout;

        public ViewHolder(View itemView) {
            super(itemView);
            layout = itemView;
            userTextName = (TextView) itemView.findViewById(R.id.userName);
            person_userImage = (ImageView) itemView.findViewById(R.id.userImage);
        }

    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return userlist.size();
    }
}


